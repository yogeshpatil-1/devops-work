# Advanced AWS GitOps AI Platform

Includes CI/CD, OPA, HPA, Argo Rollouts.